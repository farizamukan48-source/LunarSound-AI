
import numpy as np
import matplotlib.pyplot as plt

distance = np.linspace(0,100,300)
attenuation = np.exp(-0.04*distance)
signal = np.sin(0.25*distance)
intensity = attenuation * signal

plt.figure()
plt.plot(distance,intensity)
plt.title("Lunar Sound Propagation Simulation (AI + Physics)")
plt.xlabel("Distance (m)")
plt.ylabel("Amplitude")
plt.grid(True)
plt.show()
